Compiled FMIR image (self-contained package, device payload inside: Metal MSL + CUDA PTX blobs).
Built with faber 1.6.0-rc.1 (RC binary) from examples/training/bert-tiny-fragment (S6-U8 migrated package).
Run: <faber> fmir-run image.fmir --backend <metal|cuda>
