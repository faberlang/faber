Compiled FMIR image (self-contained package, device payload inside: Metal MSL + CUDA PTX blobs).
Built with faber 1.6.0-rc.1 (RC binary) from examples/training/mlp at examples 887735be3 lineage (S5/S6 fixture, pinned oracle).
Run: <faber> fmir-run image.fmir --backend <metal|cuda>
